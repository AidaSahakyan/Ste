/// <reference types="cypress" />

import { registerPage } from "../POM/registerpage/registerpage.js
";

describe('Registration Tests', () => {
    beforeEach(() => {
        // Նախքան յուրաքանչյուր թեստ, այցելում ենք գրանցման էջը
        cy.visit('https://davinci.am/index.php?route=account/register');
    });

    it('Should register successfully with valid data', () => {
        registerPage.firstName.enter('John');
        registerPage.lastName.enter('Doe');
        registerPage.email.enter('johndoe@example.com');
        registerPage.telephone.enter('+37499123456');
        registerPage.password.enter('ValidPass123');
        registerPage.confirmPassword.enter('ValidPass123');
        registerPage.agreeToTerms();
        registerPage.submit();

        // Ստուգում ենք հաջող գրանցումը
        cy.url().should('not.contain', '/register');
    });

    it('Should show error when required fields are empty', () => {
        registerPage.submit();

        // Սպասում ենք, որ սխալի հաղորդագրությունը երևա
        registerPage.elements.errorMsg()
            .should('exist')
            .should('be.visible');
    });

    it('Should show error when passwords do not match', () => {
        registerPage.firstName.enter('John');
        registerPage.lastName.enter('Doe');
        registerPage.email.enter('johndoe@example.com');
        registerPage.telephone.enter('+37499123456');
        registerPage.password.enter('ValidPass123');
        registerPage.confirmPassword.enter('DifferentPass123');
        registerPage.agreeToTerms();
        registerPage.submit();

        // Ստուգում ենք սխալի հաղորդագրությունը
        registerPage.elements.errorMsg()
            .should('exist')
            .should('be.visible')
            .should('have.text', 'Passwords do not match!');
    });

    it('Should show error for invalid email', () => {
        registerPage.firstName.enter('John');
        registerPage.lastName.enter('Doe');
        registerPage.email.enter('invalid-email');
        registerPage.telephone.enter('+37499123456');
        registerPage.password.enter('ValidPass123');
        registerPage.confirmPassword.enter('ValidPass123');
        registerPage.agreeToTerms();
        registerPage.submit();

        // Ստուգում ենք սխալի հաղորդագրությունը
        registerPage.elements.errorMsg()
            .should('exist')
            .should('be.visible')
            .should('have.text', 'Invalid E-Mail Address!');
    });
});

