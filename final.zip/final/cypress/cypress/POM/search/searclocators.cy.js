export const searchModalLocators = {
    input: '#search_query', // Որոնման դաշտի ինպուտ տարրը
    resultsContainer: '#autocomplete-results', // Ավտոմատ լրացման արդյունքների կոնտեյները
    resultList: '#ui-id-1', // Արդյունքների ցուցակի UL տարրը
    categoryFilter: 'select[name="category_id"]', // Կատեգորիայի ֆիլտրի ընտրության տարրը
}

