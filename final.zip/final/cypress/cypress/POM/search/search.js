import { searchModalLocators } from "./searchModalLocators";

class SearchModal {
    elements = {
        input: () => { return cy.get(searchModalLocators.input); },
        resultsContainer: () => { return cy.get(searchModalLocators.resultsContainer); },
        resultList: () => { return cy.get(searchModalLocators.resultList); },
        categoryFilter: () => { return cy.get(searchModalLocators.categoryFilter); }
    }

    open() {
        // Որոնման դաշտը միշտ հասանելի է, ուստի բացման հատուկ գործողություն չի պահանջվում։
        // Եթե ունենանք թաքնված որոնման դաշտ, կավելացնենք գործողություն։
    }

    enter(searchKeyword = '') {
        // Մուտքագրում է որոնման բառը
OAOAOA        this.elements.input().clear().type(searchKeyword);
OAOAOA    }

    selectCategory(categoryId) {
        // Ընտրում է կատեգորիան, եթե կա համապատասխան ID
        this.elements.categoryFilter().select(categoryId);
    }

    search() {
        // Ակտիվացնում է որոնումը (եթե կա առանձին կոճակ)
        this.elements.input().type('{enter}'); // Enter սեղմում որոնման համար
    }

    getResults() {
        // Վերադարձնում է արդյունքների ցուցակը
        return this.elements.resultsContainer().find(searchModalLocators.resultList);
    }
}

export const searchModal = new SearchModal();

