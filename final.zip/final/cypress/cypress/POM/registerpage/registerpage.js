import { registerPageLocators } from "./registerPageLocators";

class RegisterPage {
    elements = {
        firstNameInput: () => cy.get(registerPageLocators.firstNameInput),
        lastNameInput: () => cy.get(registerPageLocators.lastNameInput),
        emailInput: () => cy.get(registerPageLocators.emailInput),
        telephoneInput: () => cy.get(registerPageLocators.telephoneInput),
        passwordInput: () => cy.get(registerPageLocators.passwordInput),
        confirmPasswordInput: () => cy.get(registerPageLocators.confirmPasswordInput),
        subscribeCheckbox: () => cy.get(registerPageLocators.subscribeCheckbox),
        agreeCheckbox: () => cy.get(registerPageLocators.agreeCheckbox),
        continueBtn: () => cy.get(registerPageLocators.continueBtn),
        errorMsg: () => cy.get(registerPageLocators.errorMsg)
    };

    firstName = {
        clear: () => this.elements.firstNameInput().clear(),
        enter: (name) => this.elements.firstNameInput().clear().type(name)
    };

    lastName = {
        clear: () => this.elements.lastNameInput().clear(),
        enter: (lastName) => this.elements.lastNameInput().clear().type(lastName)
    };

    email = {
        clear: () => this.elements.emailInput().clear(),
        enter: (email) => this.elements.emailInput().clear().type(email)
    };

    telephone = {
        clear: () => this.elements.telephoneInput().clear(),
        enter: (telephone) => this.elements.telephoneInput().clear().type(telephone)
    };

    password = {
        clear: () => this.elements.passwordInput().clear(),
        enter: (password) => this.elements.passwordInput().clear().type(password)
    };

    confirmPassword = {
        clear: () => this.elements.confirmPasswordInput().clear(),
        enter: (password) => this.elements.confirmPasswordInput().clear().type(password)
    };

    subscribe() {
        this.elements.subscribeCheckbox().check();
    }

    unsubscribe() {
        this.elements.subscribeCheckbox().uncheck();
    }

    agreeToTerms() {
        this.elements.agreeCheckbox().check();
    }

    submit() {
        this.elements.continueBtn().click();
    }
}

export const registerPage = new RegisterPage();

