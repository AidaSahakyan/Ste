import { registerPage } from "./registerPage";

export default {
    assertRegistrationError(msg) {
        registerPage.elements.errorMsg()
            .should('exist')
            .should('be.visible')
            .should('have.text', msg);

        cy.url().should('contain', '/register');
    },

    assertSuccessfulRegistration() {
        registerPage.elements.errorMsg()
            .should('not.exist');

        cy.url().should('not.contain', '/register');
    }
}

