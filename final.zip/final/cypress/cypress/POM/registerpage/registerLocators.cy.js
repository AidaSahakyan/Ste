export const registerPageLocators = {
  firstNameInput: '[id="input-firstname"]',
  lastNameInput: '[id="input-lastname"]',
  emailInput: '[id="input-email"]',
  telephoneInput: '[id="input-telephone"]',
  passwordInput: '[id="input-password"]',
  confirmPasswordInput: '[id="input-confirm"]',
  newsletterYes: '[name="newsletter"][value="1"]',
  newsletterNo: '[name="newsletter"][value="0"]',
  agreeCheckbox: '[name="agree"]',
  privacyPolicyLink: '[href="https://davinci.am/index.php?route=information/information&information_id=3"]',
  submitButton: '[type="submit"]',
};

